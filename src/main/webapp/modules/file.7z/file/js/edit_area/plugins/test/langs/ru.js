editArea.add_lang("ru",{
test_select: "выбрать тэг",
test_but: "тестировать кнопку"
});
